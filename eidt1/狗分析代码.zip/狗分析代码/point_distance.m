function distance = point_distance(x1,y1,x2,y2)
distance = ((x1-x2)^2+(y1-y2)^2)^(1/2);