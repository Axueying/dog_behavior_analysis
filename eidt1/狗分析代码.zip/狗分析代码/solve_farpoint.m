function [X,Y] = solve_farpoint(Xcenter,Ycenter,LongAxis,ShortAxis,Angle)
%���룺��Xcenter,Ycenter��Ϊ���ĵ����꣬LongAxis�����ᣬShortAxis�̰��ᣬAngle����ǻ���
%{
    ������Բ����������Զ�ĵ�
%}
% Xcenter = 1;
% Ycenter = 2;
% LongAxis = 2;
% ShortAxis = 1;
% Angle = 1;
t1=0:.02:pi;
t2=pi:.02:2*pi;
z1=exp(1i*t1);
z2=exp(1i*t2);
z1=(LongAxis*real(z1)+1i*ShortAxis*imag(z1))*exp(1i*(-Angle));
z2=(LongAxis*real(z2)+1i*ShortAxis*imag(z2))*exp(1i*(-Angle));
z1=z1+Xcenter+Ycenter*1i;
z2=z2+Xcenter+Ycenter*1i;

tempxy = Xcenter+1i*Ycenter;

tempxylist = ones(size(z1,1),size(z1,2)).*tempxy;

sublist = tempxylist - z1;

tempabslist = abs(sublist);

xypos = find(tempabslist == max(tempabslist));

X = real(z1(1,xypos));
Y = imag(z1(1,xypos));

% plot(z1,'r');
% axis([-4 4 -4 4])
% axis equal
% hold on
% plot(z1(1,1),'go')
% hold on
% plot(tempxy,'bo')
% hold on
% plot(X,Y,'ko')
% hold on
% plot(z2,'r');
% hold off