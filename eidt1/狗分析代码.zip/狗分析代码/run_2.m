%{
    ��Ŀ����٣�������
%}
%% �������
clear all
close all
%% ��ȡ��Ƶ
fileName = 'G:\SIAT_PROJECT\����Ϊѧ����\����Ƶ����\20180522������ֻ��\2ֻ���罻\20180522_134945.mp4';
obj = VideoReader(fileName);
numFrames = obj.NumberOfFrames;% ֡������
height = obj.Height;
width = obj.Width;
Rate = obj.FrameRate;
%% ��һ֡������
tempfirstframe = double(rgb2gray(read(obj,1)));
imshow(tempfirstframe,[])
%% ѡ����������
title('���ѡ�������');
h=imrect;
area=round(getPosition(h));
firstframe = tempfirstframe(area(2):area(2)+area(4),area(1):area(1)+area(3),:);
close all
%% ѡ����ɫͨ����ѡ��Աȶ�����
close all
tempframe = read(obj,1);
frameR = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),1);
frameG = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),2);
frameB = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),3);
framegray = rgb2gray(tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),:));
FconR=contrast(frameR);
FconG=contrast(frameG);
FconB=contrast(frameB);
Fcongray=contrast(framegray);
FconArray = [FconR FconG FconB Fcongray];
maxcont = find(FconArray==max(FconArray(:)));
numC = 0;
switch maxcont
    case 1
        numC = 1;
    case 2
        numC = 2;
    case 3
        numC = 3;
    case 4
        numC = 4;
    otherwise
        disp('error!')
end
subplot(241)
imshow(tempframe)
subplot(242)
imshow(frameR)
subplot(243)
imshow(frameG)
subplot(244)
imshow(frameB)
subplot(245)
imshow(framegray)
subplot(246)
imhist(frameR)
subplot(247)
imhist(frameG)
subplot(248)
imhist(frameB)
%% ����λ�ñ���
DOG_num = 2;%��������
long_edge = 1.4;%���߳��ȣ���λ��
short_edge = 1.2;%�̱߳��ȣ���λ��
pixel_length = (long_edge/(area(1,3))+short_edge/(area(1,4)))/2;%ÿ�����صĳ���
position = zeros(numFrames,DOG_num*2);
fake_theta = zeros(numFrames,DOG_num);
speed = zeros(numFrames,DOG_num);%��λcm/s
accel = zeros(numFrames,DOG_num);
traceimgR = 0.*firstframe;
traceimgG = 0.*firstframe;
traceimgB = 0.*firstframe;
traceimg3 = zeros(size(traceimgR,1),size(traceimgR,2),3);
%%% ��֡��
remnum = 1;
%% ��ȡ����
close all
threshold = 0.15;
seopen = strel('disk',13);
seclose = strel('disk',7);
IntThresHoldU = 10000;
IntThresHoldD = 1;
%% ������Ƶ
for k = 250:numFrames   %%%280����2,560����2��ĸ����0
    %%%��ȡ֡
    tempframe = read(obj,k);
    %%%ѡ��Աȶ�����֡
    switch numC
        case 1
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),1);
        case 2
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),2);
        case 3
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),3);
        case 4
            frame = rgb2gray(tempframe(area(2):area(2)+area(4),...
                area(1):area(1)+area(3),:));
        otherwise
            disp('error!')
    end
    %%%��ֵ��
    bwframe = ~imbinarize(frame,threshold);
    openframe = imopen(bwframe,seopen);
%     closeframe = imclose(openframe,seclose);
    %%%�������ͨ���������
    outstats = regionprops(openframe,'Centroid','Area','Orientation',...
        'MajorAxisLength','MinorAxisLength');
    frameArea = cat(1,outstats.Area);
    frameCentroid = cat(1,outstats.Centroid);
    %%%�ȸ����ָ�������ָ�
    %%%�ж��Ƿ�����ȡ�������պ�ͼ��
    if size(frameArea,1) >= 2
        SortArea = sort(frameArea,'descend');
        %%%����ָ�
        if SortArea(1,1)>IntThresHoldU %%%������������޴󣬽���
            disp('����1');
            %%%ʹ�öԳ���ָ��
            %%%�����е�����
            tempopenframe = openframe;
            midpoint = round([(position(k-1,1)+position(k-1,3))/2,...
                (position(k-1,2)+position(k-1,4))/2]);
            for i = -1*max(size(openframe,1),size(openframe,2))*100:...
                max(size(openframe,1),size(openframe,2))*100
                %%%�����д���������㣬���д��߷ָ�ͼ��
                paramk = i*0.01;%�д����ϵڶ������λ��,ע���ߵ��ܶ�
                if(position(k-1,2)-position(k-1,4)~=0)
                    midpoint2 = round([(position(k-1,1)+position(k-1,3))/2 + paramk,...
                        (position(k-1,2)+position(k-1,4))/2 - ...
                        paramk*(position(k-1,1)-position(k-1,3))/...
                        (position(k-1,2)-position(k-1,4))]);%��ĸ���ܵ���0
                else
                    midpoint2 = round([(position(k-1,1)+position(k-1,3))/2,...
                        (position(k-1,2)+position(k-1,4))/2 + paramk]);%��ĸ����0�����
                    disp('��ĸ����0')
                end
                %%%�Ӵֱ�������Ҫ��ȫ�п�
                widthline = 3;
                if(midpoint2(1,1)+widthline<=size(tempopenframe,2)&...
                        midpoint2(1,2)+widthline<=size(tempopenframe,1)&...
                        midpoint2(1,1)-widthline>=1&...
                        midpoint2(1,2)-widthline>=1)
                    tempopenframe(midpoint2(1,2)-widthline:midpoint2(1,2)+widthline,...
                        midpoint2(1,1)-widthline:midpoint2(1,1)+widthline) = 0;
%                   imshow(tempopenframe)
%                   pause(0.000001)
%                   disp(i)
                end
            end
        elseif IntThresHoldD>SortArea(2,1)%%%��С�Ĺ����������С������
            disp('����1');
        else%%%�������
            disp('����1');
            maxArea1 = find(frameArea == SortArea(1,1));
            maxArea2 = find(frameArea == SortArea(2,1));
            position(k,1:2) = round(frameCentroid(maxArea1,:));
            position(k,3:4) = round(frameCentroid(maxArea2,:));
            %%%��������
            if k>1
                stddis1 = sum(abs(position(k,:) - position(k-1,:)));
                stddis2 = sum(abs([position(k,3:4) position(k,1:2)] - position(k-1,:)));
                if (stddis1>stddis2)
                    temppos = position(k,3:4);
                    position(k,3:4) = position(k,1:2);
                    position(k,1:2) = temppos;
                end
                disp(['����1��' num2str(stddis1)]);
                disp(['����2��' num2str(stddis2)]);
            end
            showimage1 = insertMarker(tempframe(area(2):area(2)+area(4),...
                area(1):area(1)+area(3),:), position(k,1:2) ,'o','Size',10);
            showimage2 = insertMarker(showimage1, position(k,3:4) ,'+','Size',10);
            %%%����Բ���
            Xcenter1 = position(k,1);
            Ycenter1 = position(k,2);
            LongAxis1 = outstats(maxArea1,1).MajorAxisLength;
            ShortAxis1 = outstats(maxArea1,1).MinorAxisLength;
            Angle1 = outstats(maxArea1,1).Orientation;
            Xcenter2 = position(k,3);
            Ycenter2 = position(k,4);
            LongAxis2 = outstats(maxArea2,1).MajorAxisLength;
            ShortAxis2 = outstats(maxArea2,1).MinorAxisLength;
            Angle2 = outstats(maxArea2,1).Orientation;
            %%%�������
            fake_theta(k,1) = ShortAxis1/LongAxis1;
            fake_theta(k,2) = ShortAxis2/LongAxis2;
            %%%���ƹ켣
            traceimgR(position(k,2),position(k,1)) = ...
                traceimgR(position(k,2),position(k,1)) + 1;
            traceimgG(position(k,4),position(k,3)) = ...
                traceimgG(position(k,4),position(k,3)) + 1;
            if k>1
                if abs(position(k,2)-position(k-1,2))>0 |...
                abs(position(k,1)-position(k-1,1))>0%�����ֵ
                traceimgR = DrawLineImage(traceimgR,position(k,1),position(k,2),...
                    position(k-1,1),position(k-1,2));
                end
                if abs(position(k,4)-position(k-1,4))>0 |...
                abs(position(k,3)-position(k-1,3))>0%�����ֵ
                traceimgG = DrawLineImage(traceimgG,position(k,3),position(k,4),...
                    position(k-1,3),position(k-1,4));
                end
            end
            temptraceimgR = imbinarize(traceimgR,0)*255;
            temptraceimgG = imbinarize(traceimgG,0)*255;
            temptraceimgB = imbinarize(traceimgB,0)*255;
            traceimg3(:,:,1) = temptraceimgR;
            traceimg3(:,:,2) = temptraceimgG;
            traceimg3(:,:,3) = temptraceimgB;
            subplot(221)
            imshow(showimage2)
            hold on
            PlotEllipse(Xcenter1,Ycenter1,LongAxis1/2,ShortAxis1/2,Angle1/180*pi);
            hold off
            hold on
            PlotEllipse(Xcenter2,Ycenter2,LongAxis2/2,ShortAxis2/2,Angle2/180*pi);
            hold off
            subplot(222)
            imshow(traceimg3)
            subplot(223)
            imshow(openframe)
            pause(0.00000001)
        end
    elseif size(frameArea,1) == 1%%%�����򽻻�          
        if IntThresHoldD>frameArea(1,1)%%%��С�Ĺ����������С������
            disp('����2');
        else%%%����
            disp('����2');
            %%%ʹ�öԳ���ָ��
            %%%�����е�����
            tempopenframe = openframe;
            midpoint = round([(position(k-1,1)+position(k-1,3))/2,...
                (position(k-1,2)+position(k-1,4))/2]);
            for i = -1*max(size(openframe,1),size(openframe,2))*100:...
                max(size(openframe,1),size(openframe,2))*100
                %%%�����д���������㣬���д��߷ָ�ͼ��
                paramk = i*0.01;%�д����ϵڶ������λ��,ע���ߵ��ܶ�
                if(position(k-1,2)-position(k-1,4)~=0)
                    midpoint2 = round([(position(k-1,1)+position(k-1,3))/2 + paramk,...
                        (position(k-1,2)+position(k-1,4))/2 - ...
                        paramk*(position(k-1,1)-position(k-1,3))/...
                        (position(k-1,2)-position(k-1,4))]);%��ĸ���ܵ���0
                else
                    midpoint2 = round([(position(k-1,1)+position(k-1,3))/2,...
                        (position(k-1,2)+position(k-1,4))/2 + paramk]);%��ĸ����0�����
                    disp('��ĸ����0')
                end
                %%%�Ӵֱ�������Ҫ��ȫ�п�
                widthline = 3;
                if(midpoint2(1,1)+widthline<=size(tempopenframe,2)&...
                        midpoint2(1,2)+widthline<=size(tempopenframe,1)&...
                        midpoint2(1,1)-widthline>=1&...
                        midpoint2(1,2)-widthline>=1)
                    tempopenframe(midpoint2(1,2)-widthline:midpoint2(1,2)+widthline,...
                        midpoint2(1,1)-widthline:midpoint2(1,1)+widthline) = 0;
                    disp('�ɹ��п�');
                    if rem(i,500) == 0
                        subplot(224)
                        imshow(tempopenframe)
                        pause(0.000001)
                        disp(i)
                    end
                end
            end
            %%%�������ͨ���������
            outstats2 = regionprops(tempopenframe,'Centroid','Area','Orientation',...
                'MajorAxisLength','MinorAxisLength');
            frameArea = cat(1,outstats2.Area);
            frameCentroid = cat(1,outstats2.Centroid);
            SortArea = sort(frameArea,'descend');
            maxArea1 = find(frameArea == SortArea(1,1));
            maxArea2 = find(frameArea == SortArea(2,1));
            position(k,1:2) = round(frameCentroid(maxArea1,:));
            position(k,3:4) = round(frameCentroid(maxArea2,:));
            %%%��������
            if k>1
                stddis1 = sum(abs(position(k,:) - position(k-1,:)));
                stddis2 = sum(abs([position(k,3:4) position(k,1:2)] - position(k-1,:)));
                if (stddis1>stddis2)
                    temppos = position(k,3:4);
                    position(k,3:4) = position(k,1:2);
                    position(k,1:2) = temppos;
                end
                disp(['����1��' num2str(stddis1)]);
                disp(['����2��' num2str(stddis2)]);
            end
            %%%����Բ���
            Xcenter1 = position(k,1);
            Ycenter1 = position(k,2);
            LongAxis1 = outstats2(maxArea1,1).MajorAxisLength;
            ShortAxis1 = outstats2(maxArea1,1).MinorAxisLength;
            Angle1 = outstats2(maxArea1,1).Orientation;
            Xcenter2 = position(k,3);
            Ycenter2 = position(k,4);
            LongAxis2 = outstats2(maxArea2,1).MajorAxisLength;
            ShortAxis2 = outstats2(maxArea2,1).MinorAxisLength;
            Angle2 = outstats2(maxArea2,1).Orientation;
            %%%�������
            fake_theta(k,1) = ShortAxis1/LongAxis1;
            fake_theta(k,2) = ShortAxis2/LongAxis2;
            %%%���ƹ켣
            traceimgR(position(k,2),position(k,1)) = ...
                traceimgR(position(k,2),position(k,1)) + 1;
            traceimgG(position(k,4),position(k,3)) = ...
                traceimgG(position(k,4),position(k,3)) + 1;
            if k>1
                if abs(position(k,2)-position(k-1,2))>0 |...
                abs(position(k,1)-position(k-1,1))>0%�����ֵ
                traceimgR = DrawLineImage(traceimgR,position(k,1),position(k,2),...
                    position(k-1,1),position(k-1,2));
                end
                if abs(position(k,4)-position(k-1,4))>0 |...
                abs(position(k,3)-position(k-1,3))>0%�����ֵ
                traceimgG = DrawLineImage(traceimgG,position(k,3),position(k,4),...
                    position(k-1,3),position(k-1,4));
                end
            end
            temptraceimgR = imbinarize(traceimgR,0)*255;
            temptraceimgG = imbinarize(traceimgG,0)*255;
            temptraceimgB = imbinarize(traceimgB,0)*255;
            traceimg3(:,:,1) = temptraceimgR;
            traceimg3(:,:,2) = temptraceimgG;
            traceimg3(:,:,3) = temptraceimgB;
            showimage1 = insertMarker(tempframe(area(2):area(2)+area(4),...
                area(1):area(1)+area(3),:), position(k,1:2) ,'o','Size',10);
            showimage2 = insertMarker(showimage1, position(k,3:4) ,'+','Size',10);
            subplot(221)
            imshow(showimage2)
            hold on
            PlotEllipse(Xcenter1,Ycenter1,LongAxis1/2,ShortAxis1/2,Angle1/180*pi);
            hold off
            hold on
            PlotEllipse(Xcenter2,Ycenter2,LongAxis2/2,ShortAxis2/2,Angle2/180*pi);
            hold off
            subplot(222)
            imshow(traceimg3)
            subplot(223)
            imshow(openframe)
            pause(0.00000001)
        end
    else 
        disp('����3');
    end
%     subplot(121)
%     imshow(frame)
%     subplot(122)
%     imshow(openframe)
%     maxArea = find(frameArea == max(frameArea(:)));
%     position(k,:) = round(frameCentroid(maxArea,:));
%     showimage = insertMarker(tempframe(area(2):area(2)+area(4),...
%                 area(1):area(1)+area(3),:), position(k,:) ,'o','Size',10);
%     %%%����Բ���
%     Xcenter = position(k,1);
%     Ycenter = position(k,2);
%     LongAxis = outstats(maxArea,1).MajorAxisLength;
%     ShortAxis = outstats(maxArea,1).MinorAxisLength;
%     Angle = outstats(maxArea,1).Orientation;
%     %%%�������
%     fake_theta(k,1) = ShortAxis/LongAxis;
%     if k>1
%         speed(k,1) = 100*(((position(k,1)-position(k-1,1))^2 + ...
%             (position(k,2)-position(k-1,2))^2)^0.5)*pixel_length*Rate;
%         accel(k,1) = (speed(k,1) - speed(k-1,1))*Rate;
%     end
%     %%%���ƹ켣
%     traceimg(position(k,2),position(k,1)) = ...
%          traceimg(position(k,2),position(k,1)) + 1;
%      if k>1
%           if abs(position(k,2)-position(k-1,2))>0 |...
%          abs(position(k,1)-position(k-1,1))>0%�����ֵ
%             traceimg = DrawLineImage(traceimg,position(k,1),position(k,2),...
%                 position(k-1,1),position(k-1,2));
% %             disp(position(k,2)-position(k-1,2))
% %             disp(position(k,1)-position(k-1,1))
%           end
%      end
%      temptraceimg = imbinarize(traceimg,0)*255;
%      traceimg3(:,:,1) = temptraceimg;
%      traceimg3(:,:,2) = temptraceimg;
%      traceimg3(:,:,3) = temptraceimg;
%      saveimg = [showimage traceimg3];
%     %%%��ʾ֡
%     if rem(k,remnum) == 0
% %         subplot(211)
% %         imshow(closeframe)
% %         subplot(212)
%         imshow(saveimg)
%         hold on
%         PlotEllipse(Xcenter,Ycenter,LongAxis/2,ShortAxis/2,Angle/180*pi);
%         hold off
%         text(0,8,['λ�ã�[' num2str(position(k,1)) ',' num2str(position(k,2)) ']']...
%              ,'horiz','left','color','y')
%         text(0,24,['��һ��תͷ�Ƕȣ�' num2str(fake_theta(k,1),4)]...
%              ,'horiz','left','color','y')
%         if speed(k,1) == 0
%             text(0,40,['�ٶȣ�' '0.000' 'cm/s']...
%                 ,'horiz','left','color','y') 
%         else
%             text(0,40,['�ٶȣ�' num2str(speed(k,1),4) 'cm/s']...
%                  ,'horiz','left','color','y') 
%         end
%     end
    pause(0.00000001)
    disp(k)
end