%{
    ��Ŀ����٣�һ����
%}
%% �������
clear all
close all
%% ��ȡ��Ƶ
fileName = 'G:\SIAT_PROJECT\����Ϊѧ����\����Ƶ����\20180518����\20180518_134414.mp4';
%fileName = 'G:\SIAT_PROJECT\����Ϊѧ����\����Ƶ����\20180522������ֻ��\2ֻ���罻\20180522_134945.mp4';
obj = VideoReader(fileName);
numFrames = obj.NumberOfFrames;% ֡������
height = obj.Height;
width = obj.Width;
Rate = obj.FrameRate;
%% ��һ֡������
tempfirstframe = double(rgb2gray(read(obj,1)));
imshow(tempfirstframe,[])
%% ѡ����������
title('���ѡ�������');
h=imrect;
area=round(getPosition(h));
firstframe = tempfirstframe(area(2):area(2)+area(4),area(1):area(1)+area(3),:);
%% ѡ����ɫͨ����ѡ��Աȶ�����
close all
tempframe = read(obj,1);
frameR = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),1);
frameG = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),2);
frameB = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),3);
framegray = rgb2gray(tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),:));
FconR=contrast(frameR);
FconG=contrast(frameG);
FconB=contrast(frameB);
Fcongray=contrast(framegray);
FconArray = [FconR FconG FconB Fcongray];
maxcont = find(FconArray==max(FconArray(:)));
numC = 0;
switch maxcont
    case 1
        numC = 1;
    case 2
        numC = 2;
    case 3
        numC = 3;
    case 4
        numC = 4;
    otherwise
        disp('error!')
end
subplot(241)
imshow(tempframe)
subplot(242)
imshow(frameR)
subplot(243)
imshow(frameG)
subplot(244)
imshow(frameB)
subplot(245)
imshow(framegray)
subplot(246)
imhist(frameR)
subplot(247)
imhist(frameG)
subplot(248)
imhist(frameB)
%% ��ȡ����
close all
threshold = 0.2;
seopen = strel('disk',2);
seclose = strel('disk',7);
%% ����λ�ñ���
DOG_num = 1;%��������
long_edge = 1.4;%���߳��ȣ���λ��
short_edge = 1.2;%�̱߳��ȣ���λ��
pixel_length = (long_edge/(area(1,3))+short_edge/(area(1,4)))/2;%ÿ�����صĳ���
position = zeros(numFrames,DOG_num*2);
fake_theta = zeros(numFrames,DOG_num);
speed = zeros(numFrames,DOG_num);%��λcm/s
accel = zeros(numFrames,DOG_num);
traceimg = 0.*firstframe;
traceimg3 = zeros(size(traceimg,1),size(traceimg,2),3);
%%% ��֡��
remnum = 1;
%% ������Ƶ
for k = 1:numFrames
    %%%��ȡ֡
    tempframe = read(obj,k);
    %%%ѡ��Աȶ�����֡
    switch numC
        case 1
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),1);
        case 2
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),2);
        case 3
            frame = tempframe(area(2):area(2)+area(4),area(1):area(1)+area(3),3);
        case 4
            frame = rgb2gray(tempframe(area(2):area(2)+area(4),...
                area(1):area(1)+area(3),:));
        otherwise
            disp('error!')
    end
    %%%��ֵ��
    bwframe = ~imbinarize(frame,threshold);
    openframe = imopen(bwframe,seopen);
    closeframe = imclose(openframe,seclose);
    %%%�������ͨ���������
    outstats = regionprops(closeframe,'Centroid','Area','Orientation',...
        'MajorAxisLength','MinorAxisLength');
    frameArea = cat(1,outstats.Area);
    frameCentroid = cat(1,outstats.Centroid);
    maxArea = find(frameArea == max(frameArea(:)));
    position(k,:) = round(frameCentroid(maxArea,:));
    showimage = insertMarker(tempframe(area(2):area(2)+area(4),...
                area(1):area(1)+area(3),:), position(k,:) ,'o','Size',10);
    %%%����Բ���
    Xcenter = position(k,1);
    Ycenter = position(k,2);
    LongAxis = outstats(maxArea,1).MajorAxisLength;
    ShortAxis = outstats(maxArea,1).MinorAxisLength;
    Angle = outstats(maxArea,1).Orientation;
    %%%�������
    fake_theta(k,1) = ShortAxis/LongAxis;
    if k>1
        speed(k,1) = 100*(((position(k,1)-position(k-1,1))^2 + ...
            (position(k,2)-position(k-1,2))^2)^0.5)*pixel_length*Rate;
        accel(k,1) = (speed(k,1) - speed(k-1,1))*Rate;
    end
    %%%���ƹ켣
    traceimg(position(k,2),position(k,1)) = ...
         traceimg(position(k,2),position(k,1)) + 1;
     if k>1
          if abs(position(k,2)-position(k-1,2))>0 |...
         abs(position(k,1)-position(k-1,1))>0%�����ֵ
            traceimg = DrawLineImage(traceimg,position(k,1),position(k,2),...
                position(k-1,1),position(k-1,2));
          end
     end
     temptraceimg = imbinarize(traceimg,0)*255;
     traceimg3(:,:,1) = temptraceimg;
     traceimg3(:,:,2) = temptraceimg;
     traceimg3(:,:,3) = temptraceimg;
     saveimg = [showimage traceimg3];
    %%%��ʾ֡
    if rem(k,remnum) == 0
%         subplot(211)
%         imshow(closeframe)
%         subplot(212)
        imshow(saveimg)
        hold on
        PlotEllipse(Xcenter,Ycenter,LongAxis/2,ShortAxis/2,Angle/180*pi);
        hold off
        text(0,8,['λ�ã�[' num2str(position(k,1)) ',' num2str(position(k,2)) ']']...
             ,'horiz','left','color','y')
        text(0,24,['��һ��תͷ�Ƕȣ�' num2str(fake_theta(k,1),4)]...
             ,'horiz','left','color','y')
        if speed(k,1) == 0
            text(0,40,['�ٶȣ�' '0.000' 'cm/s']...
                ,'horiz','left','color','y') 
        else
            text(0,40,['�ٶȣ�' num2str(speed(k,1),4) 'cm/s']...
                 ,'horiz','left','color','y') 
        end
    end
%     text(370,56,['���ٶȣ�' num2str(accel(k,1)) 'cm/s^2']...
%          ,'horiz','left','color','y') 
%     subplot(221)
%     imshow(frame)
%      text(3,4,['λ�ã�[' num2str(position(k,1)) ',' num2str(position(k,2)) ']']...
%          ,'horiz','center','color','r') 
%     title(['λ�ã�[' num2str(position(k,1)) ',' num2str(position(k,2)) ']'])
%     subplot(222)
%     imshow(bwframe)
%     title(['��һ��תͷ�Ƕȣ�' num2str(fake_theta(k,1))]);
%     subplot(223)
%     imshow(showimage)
%     title(['�ٶȣ�' num2str(speed(k,1))]);
%     hold on
%     PlotEllipse(Xcenter,Ycenter,LongAxis/2,ShortAxis/2,Angle/180*pi);
%     hold off
%     subplot(224)
%     imshow(traceimg)
%     title(['���ٶȣ�' num2str(accel(k,1))]);
    pause(0.00000001)
    disp(k)
end
%% ��ͼ
recsize = 21;
filter = conv2(ones(recsize,recsize),ones(recsize,recsize));
newtraceimg = log(mat2gray(conv2(traceimg,filter))+1);
imagesc(newtraceimg);
colormap('jet');
figure(gcf);colorbar;