function [xpoint1,ypoint1,xpoint2,ypoint2] = collineation_point2(img,x1,y1,x2,y2)
%{
    ���㹲�߽߱����꣬������ֵ�ڻҶ�ͼ��Χ֮�ڵ�
%}

img_size_x = size(img,2);
img_size_y = size(img,1);

x_first = 1;
y_first = 1;
x_last = img_size_x;
y_last = img_size_y;

if x2 == x1
    xpoint1 = x1;
    ypoint1 = 1;
    xpoint2 = x2;
    ypoint2 = y_last;
    disp('x2 == x1');
elseif y2 == y1
    xpoint1 = 1;
    ypoint1 = y1;
    xpoint2 = x_last;
    ypoint2 = y2;
    disp('x2 == x1');
else
    %ֱ�߷��̣�y = round((y2-y1)/(x2-x1)*(x-x1)+y1)
    %ֱ�߷��̣�x = round((x2-x1)/(y2-y1)*(y-y1)+x1)
    x_first_cal_y = round((y2-y1)/(x2-x1)*(x_first-x1)+y1);
    x_last_cal_y = round((y2-y1)/(x2-x1)*(x_last-x1)+y1);
    y_first_cal_x = round((x2-x1)/(y2-y1)*(y_first-y1)+x1);
    y_last_cal_x = round((x2-x1)/(y2-y1)*(y_last-y1)+x1);
    point = [x_first,x_first_cal_y;x_last,x_last_cal_y;...
        y_first_cal_x,y_first;y_last_cal_x,y_last];
    pos = point(:,1)<=x_last&point(:,1)>=1&...
        point(:,2)<=y_last&point(:,2)>=1;
    newpoint = point(pos,:);
    if size(newpoint,1) == 2
        temppoint = unique(newpoint,'rows');
        xpoint1 = temppoint(1,1);
        ypoint1 = temppoint(1,2);
        xpoint2 = temppoint(2,1);
        ypoint2 = temppoint(2,2);
    elseif size(newpoint,1) == 3
        temppoint1 = unique(newpoint(:,1),'rows');
        temppoint2 = unique(newpoint(:,2),'rows');
        %%%һ����һ������ֻʣ������
        if size(temppoint1,1) == 2
            pos1 = find(temppoint1(1,1) == newpoint(:,1));
            pos2 = find(temppoint1(1,1) ~= newpoint(:,1));
            temppoint = [newpoint(pos1(1,1),:);...
                        newpoint(pos2,:)];
            xpoint1 = temppoint(1,1);
            ypoint1 = temppoint(1,2);
            xpoint2 = temppoint(2,1);
            ypoint2 = temppoint(2,2);
        else
            pos1 = find(temppoint2(1,1) == newpoint(:,2));
            pos2 = find(temppoint2(1,1) ~= newpoint(:,2));
            temppoint = [newpoint(pos1(1,1),:);...
                        newpoint(pos2,:)];
            xpoint1 = temppoint(1,1);
            ypoint1 = temppoint(1,2);
            xpoint2 = temppoint(2,1);
            ypoint2 = temppoint(2,2);
        end
    elseif size(newpoint,1) == 4
        temppoint1 = unique(newpoint(:,1),'rows');
        temppoint2 = unique(newpoint(:,2),'rows');
        %%%һ����һ������ֻʣ������
        if size(temppoint1,1) == 2
            pos1 = find(temppoint1(1,1) == newpoint(:,1));
            pos2 = find(temppoint1(1,1) ~= newpoint(:,1));
            temppoint = [newpoint(pos1(1,1),:);...
                        newpoint(pos2,:)];
            xpoint1 = temppoint(1,1);
            ypoint1 = temppoint(1,2);
            xpoint2 = temppoint(2,1);
            ypoint2 = temppoint(2,2);
        else
            pos1 = find(temppoint2(1,1) == newpoint(:,2));
            pos2 = find(temppoint2(1,1) ~= newpoint(:,2));
            temppoint = [newpoint(pos1(1,1),:);...
                        newpoint(pos2,:)];
            xpoint1 = temppoint(1,1);
            ypoint1 = temppoint(1,2);
            xpoint2 = temppoint(2,1);
            ypoint2 = temppoint(2,2);
        end
    else
        error('�Ҳ�������Ҫ�ĵ㣡');
    end
end
% disp(['[x_first x_first_cal_y]:[' num2str(x_first) ',' num2str(x_first_cal_y) ']']);
% disp(['[x_last x_last_cal_y]:[' num2str(x_last) ',' num2str(x_last_cal_y) ']']);
% disp(['[y_first_cal_x y_first]:[' num2str(y_first) ',' num2str(y_first_cal_x) ']']);
% disp(['[y_last_cal_x y_last]:[' num2str(y_last) ',' num2str(y_last_cal_x) ']']);
disp(['[xpoint1,ypoint1,xpoint2,ypoint2]:[' num2str(xpoint1) ...
    ',' num2str(ypoint1) ',' num2str(xpoint2) ',' num2str(ypoint2) ']']);